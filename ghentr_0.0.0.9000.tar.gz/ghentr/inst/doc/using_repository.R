## ----echo = FALSE--------------------------------------------------------
knitr::opts_chunk$set(eval = FALSE)

## ------------------------------------------------------------------------
#  options(
#    repos = c(
#      CRAN = "https://cran.rstudio.com/",
#      ACMERAN = "https://pages.github.acme-corp.com/ACME-R/ACMERAN/" # add a line like this
#    ),
#    ...
#  )

## ------------------------------------------------------------------------
#  usethis::create_project("path/to/ACMERAN")

## ------------------------------------------------------------------------
#  ghentr::init_drat_repo()

## ------------------------------------------------------------------------
#  options(
#    dratRepo = "path/to/ACMERAN",
#    ...
#  )

## ------------------------------------------------------------------------
#  usethis::use_git()

## ------------------------------------------------------------------------
#  acmetools::use_github_acme()

## ------------------------------------------------------------------------
#  basename(getOption("dratRepo")) # check to see if "equivalent" to repository name

## ------------------------------------------------------------------------
#  # use one of these
#  
#  # yes - name is equivalent
#  ghentr::use_drat_repo()
#  
#  # no - name is not eqivalent
#  ghentr::use_repo("ACMERAN")

## ------------------------------------------------------------------------
#  devtools::check()
#  devtools::build()

## ------------------------------------------------------------------------
#  drat::insertPackage("path/to/boomerang.tar.gz")

## ------------------------------------------------------------------------
#  options(
#    repos = c(
#      CRAN = "https://cran.rstudio.com/",
#      ACMERAN = "file://path/to/ACMERAN/"
#    ),
#    ...
#  )

