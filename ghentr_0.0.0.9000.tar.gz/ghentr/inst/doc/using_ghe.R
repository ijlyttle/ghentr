## ----echo = FALSE--------------------------------------------------------
knitr::opts_chunk$set(eval = FALSE)

## ------------------------------------------------------------------------
#  # You may want to call your package something different,
#  # as well as specify a different path on your computer.
#  usethis::create_package("~/r-packages/acmetools")

## ------------------------------------------------------------------------
#  ghentr::use_github_enterprise(
#    host = "github.acme-corp.com/api/v3",
#    suffix = "acme",
#    name = "Acme Corporation"
#  )

## ------------------------------------------------------------------------
#  # install.packages("devtools")
#  devtools::install_github("<your-account-here>/acmetools", host = "github.acme-corp.com/api/v3")

## ------------------------------------------------------------------------
#  install_github_acme <- function(repo,
#                                  username = NULL,
#                                  ref = "master",
#                                  subdir = NULL,
#                                  auth_token = github_acme_pat(quiet),
#                                  host = "github.acme-corp.com/api/v3",
#                                  quiet = FALSE,
#                                  ...){
#    devtools::install_github(
#      repo,
#      username = username,
#      ref = ref,
#      subdir = subdir,
#      auth_token = auth_token,
#      host = host,
#      quiet = quiet,
#      ...
#    )
#  }

## ------------------------------------------------------------------------
#  use_github_acme <- function(organisation = NULL,
#                              private = FALSE,
#                              protocol = c("ssh", "https"),
#                              credentials = NULL,
#                              auth_token = github_acme_pat(),
#                              host = "https://github.acme-corp.com/api/v3") {
#  
#    usethis::use_github(
#      organisation = organisation,
#      private = private,
#      protocol = protocol,
#      credentials = credentials,
#      auth_token = auth_token,
#      host = host
#    )
#  }

## ------------------------------------------------------------------------
#  github_acme_pat <- function(quiet = FALSE) {
#  
#    pat <- Sys.getenv("GITHUB_ACME_PAT")
#    if (nzchar(pat)) {
#      if (!quiet) {
#        message("Using GitHub PAT from envvar GITHUB_ACME_PAT")
#      }
#      return(pat)
#    }
#  }

